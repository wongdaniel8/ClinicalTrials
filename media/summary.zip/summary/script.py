"""
Analysis script written by the CRO for the CRF data received from the trial investigator. 
We do not have access to the actual script used in the real clinical trial SDY1. 
This is not the real analysis used, but merely a placeholder to demonstrate proof of concept.
"""

def getControlAdverses():
	return

def getPValueAdverses():
	return

def getAverageMonocyteConcentrationArm1():
	return

def compareFreeIgECountsAcrossArms():
	return

def getRagweedImmunoDistribution():
	return 

def getPearsonEffective():
	return

def getIgGaMeasurement():
	return 

